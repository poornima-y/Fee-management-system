<?php

if(!isset($_SESSION['rainbow_uid']))
echo '<script type="text/javascript">window.location="login.php"; </script>';


?>